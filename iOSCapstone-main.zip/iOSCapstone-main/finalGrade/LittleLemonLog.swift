//
//  LittleLemonLog.swift
//  finalGrade
//
//  Created by Li Tong on 2/28/24.
//

import SwiftUI

struct LittleLemonLog: View {
    var body: some View {
        Image("littleLemonLogo")
    }
}

#Preview {
    LittleLemonLog()
}
